﻿namespace Bit.Sso.Models;

public class RedirectViewModel
{
    public string RedirectUrl { get; set; }
}
