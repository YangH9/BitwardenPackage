﻿namespace Bit.Api.Billing.Models;

public class UpdateProviderOrganizationRequestBody
{
    public int AssignedSeats { get; set; }
}
