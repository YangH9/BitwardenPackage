﻿namespace Bit.Admin;

public class AdminSettings
{
    public virtual string Admins { get; set; }
    public int? DeleteTrashDaysAgo { get; set; }
}
