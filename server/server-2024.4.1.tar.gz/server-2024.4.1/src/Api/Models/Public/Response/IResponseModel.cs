﻿namespace Bit.Api.Models.Public.Response;

public interface IResponseModel
{
    string Object { get; }
}
