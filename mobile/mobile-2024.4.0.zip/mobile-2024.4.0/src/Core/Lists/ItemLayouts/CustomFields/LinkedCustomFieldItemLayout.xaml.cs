﻿using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace Bit.App.Lists.ItemLayouts.CustomFields
{
    public partial class LinkedCustomFieldItemLayout : StackLayout
    {
        public LinkedCustomFieldItemLayout()
        {
            InitializeComponent();
        }
    }
}
