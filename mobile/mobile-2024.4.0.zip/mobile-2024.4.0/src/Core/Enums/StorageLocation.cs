﻿namespace Bit.Core.Enums
{
    public enum StorageLocation
    {
        Both = 0,
        Disk = 1,
        Memory = 2
    }
}
