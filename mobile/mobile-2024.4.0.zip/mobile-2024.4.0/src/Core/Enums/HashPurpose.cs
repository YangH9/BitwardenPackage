﻿namespace Bit.Core.Enums
{
    public enum HashPurpose : byte
    {
        ServerAuthorization = 1,
        LocalAuthorization = 2,
    }
}
