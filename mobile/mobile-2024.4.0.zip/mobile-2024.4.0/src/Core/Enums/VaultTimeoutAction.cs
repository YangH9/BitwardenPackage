﻿namespace Bit.Core.Enums
{
    public enum VaultTimeoutAction
    {
        Lock = 0,
        Logout = 1,
    }
}
