﻿namespace Bit.Core.Enums
{
    public enum HkdfAlgorithm : byte
    {
        Sha256 = 1,
        Sha512 = 2,
    }
}
