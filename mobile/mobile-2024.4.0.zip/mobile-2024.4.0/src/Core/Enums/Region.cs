﻿namespace Bit.Core.Enums
{
    public enum Region
    {
        US,
        EU,
        SelfHosted
    }
}

