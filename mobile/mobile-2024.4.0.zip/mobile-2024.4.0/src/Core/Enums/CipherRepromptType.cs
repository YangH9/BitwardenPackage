﻿namespace Bit.Core.Enums
{
    public enum CipherRepromptType : byte
    {
        None = 0,
        Password = 1,
    }
}
