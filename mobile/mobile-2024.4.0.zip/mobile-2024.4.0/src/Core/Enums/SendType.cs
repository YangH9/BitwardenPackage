﻿namespace Bit.Core.Enums
{
    public enum SendType
    {
        Text = 0,
        File = 1,
    }
}
