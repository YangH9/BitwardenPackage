﻿namespace Bit.Core.Models.Request
{
    public class DeviceTokenRequest
    {
        public string PushToken { get; set; }
    }
}
