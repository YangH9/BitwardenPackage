﻿using System;
namespace Bit.Core.Models.Request
{
    public class OrganizationDomainSsoDetailsRequest
    {
        public string Email { get; set; }
    }
}

