﻿namespace Bit.Core.Models.Request
{
    public class PasswordHintRequest
    {
        public string Email { get; set; }
    }
}
