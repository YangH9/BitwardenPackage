﻿namespace Bit.Core.Models.Request
{
    public class KeysRequest
    {
        public string PublicKey { get; set; }
        public string EncryptedPrivateKey { get; set; }
    }
}
