﻿namespace Bit.Core.Models.Request
{
    public class PasswordVerificationRequest
    {
        public string MasterPasswordHash { get; set; }
    }
}
