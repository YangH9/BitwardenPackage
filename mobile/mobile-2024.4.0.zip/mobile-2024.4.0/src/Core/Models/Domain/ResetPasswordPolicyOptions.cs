﻿namespace Bit.Core.Models.Domain
{
    public class ResetPasswordPolicyOptions
    {
        public bool AutoEnrollEnabled { get; set; }
    }
}
