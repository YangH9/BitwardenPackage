﻿namespace Bit.Core.Models.Domain
{
    public interface ITreeNodeObject
    {
        string Id { get; set; }
        string Name { get; set; }
    }
}
