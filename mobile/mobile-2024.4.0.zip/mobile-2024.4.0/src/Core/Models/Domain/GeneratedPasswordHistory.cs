﻿using System;

namespace Bit.Core.Models.Domain
{
    public class GeneratedPasswordHistory
    {
        public string Password { get; set; }
        public DateTime Date { get; set; }
    }
}
