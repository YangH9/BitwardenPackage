﻿using Bit.Core.Enums;

namespace Bit.Core.Models.Api
{
    public class SecureNoteApi
    {
        public SecureNoteType Type { get; set; }
    }
}
