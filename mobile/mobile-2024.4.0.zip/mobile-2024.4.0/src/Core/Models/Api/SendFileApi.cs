﻿namespace Bit.Core.Models.Api
{
    public class SendFileApi
    {
        public string Id { get; set; }
        public string FileName { get; set; }
        public string Key { get; set; }
        public string Size { get; set; }
        public string SizeName { get; set; }
    }
}
