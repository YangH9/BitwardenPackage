﻿namespace Bit.Core.Models.Response
{
    public class OrganizationAutoEnrollStatusResponse
    {
        public string Id { get; set; }
        public bool ResetPasswordEnabled { get; set; }
    }
}
