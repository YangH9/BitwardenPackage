﻿namespace Bit.Core.Models.Response
{
    public class OrganizationKeysResponse
    {
        public string PrivateKey { get; set; }
        public string PublicKey { get; set; }
    }
}
