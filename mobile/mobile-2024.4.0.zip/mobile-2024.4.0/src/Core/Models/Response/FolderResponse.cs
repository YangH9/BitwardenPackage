﻿using System;

namespace Bit.Core.Models.Response
{
    public class FolderResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public DateTime RevisionDate { get; set; }
    }
}
