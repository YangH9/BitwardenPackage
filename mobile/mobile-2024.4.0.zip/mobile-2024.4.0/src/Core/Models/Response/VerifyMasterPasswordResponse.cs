﻿using Bit.Core.Models.Domain;

namespace Bit.Core.Models.Response
{
    public class VerifyMasterPasswordResponse
    {
        public MasterPasswordPolicyOptions MasterPasswordPolicy { get; set; }
    }
}
