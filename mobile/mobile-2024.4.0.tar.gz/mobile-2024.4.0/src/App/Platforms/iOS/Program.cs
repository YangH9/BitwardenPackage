﻿using Bit.iOS;
using UIKit;

namespace Bit.App;

public class Program
{
    static void Main(string[] args)
    {
        UIApplication.Main(args, null, typeof(AppDelegate));
    }
}
