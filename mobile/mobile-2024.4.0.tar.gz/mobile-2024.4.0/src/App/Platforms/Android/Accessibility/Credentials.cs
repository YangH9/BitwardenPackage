namespace Bit.Droid.Accessibility
{
    public class Credentials
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Uri { get; set; }
        public string LastUri { get; set; }
    }
}
