﻿namespace Bit.Droid.Autofill
{
    public class AutofillConstants
    {
        public const string AutofillFramework = "autofillFramework";
        public const string AutofillFrameworkFillType = "autofillFrameworkFillType";
        public const string AutofillFrameworkUri = "autofillFrameworkUri";
        public const string AutofillFrameworkCipherId = "autofillFrameworkCipherId";
    }
}
