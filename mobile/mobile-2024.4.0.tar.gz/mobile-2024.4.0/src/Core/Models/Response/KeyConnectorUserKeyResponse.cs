﻿using System;

namespace Bit.Core.Models.Response
{
    public class KeyConnectorUserKeyResponse
    {
        public string Key { get; set; }
    }
}
