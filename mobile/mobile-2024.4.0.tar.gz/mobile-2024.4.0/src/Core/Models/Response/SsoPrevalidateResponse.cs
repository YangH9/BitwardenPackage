﻿namespace Bit.Core.Models.Response
{
    public class SsoPrevalidateResponse
    {
        public string Token { get; set; }
    }
}
