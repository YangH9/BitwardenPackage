﻿namespace Bit.Core.Models.Response
{
    public class AttachmentResponse
    {
        public string Id { get; set; }
        public string Url { get; set; }
        public string FileName { get; set; }
        public string Key { get; set; }
        public string Size { get; set; }
        public string SizeName { get; set; }
    }
}
