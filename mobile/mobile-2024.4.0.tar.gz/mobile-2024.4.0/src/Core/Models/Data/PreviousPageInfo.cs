﻿namespace Bit.Core.Models.Data
{
    public class PreviousPageInfo
    {
        public string Page { get; set; }
        public string CipherId { get; set; }
        public string SendId { get; set; }
        public string SearchText { get; set; }
    }
}
