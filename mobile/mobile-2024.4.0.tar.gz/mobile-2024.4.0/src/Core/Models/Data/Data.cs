﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bit.Core.Models.Data
{
    public abstract class Data
    {
    }
}
