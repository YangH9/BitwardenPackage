﻿namespace Bit.Core.Models.Request
{
    public class PreloginRequest
    {
        public string Email { get; set; }
    }
}
