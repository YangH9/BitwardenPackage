﻿namespace Bit.Core.Models.Api
{
    public class SendTextApi
    {
        public string Text { get; set; }
        public bool Hidden { get; set; }
    }
}
