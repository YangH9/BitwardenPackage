﻿namespace Bit.Core.Models.Domain
{
    public class Message
    {
        public string Command { get; set; }
        public object Data { get; set; }
    }
}
