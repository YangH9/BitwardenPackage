﻿using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace Bit.App.Controls
{
    public class CustomLabel : Label
    {
        public CustomLabel()
        {
        }

        public int? FontWeight { get; set; }
    }
}
