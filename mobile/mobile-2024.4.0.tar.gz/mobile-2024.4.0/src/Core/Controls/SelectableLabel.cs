﻿using System;
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace Bit.App.Controls
{
    public class SelectableLabel : Label
    {

    }
}
