﻿namespace Bit.Core.Enums
{
    public enum NavigationTarget
    {
        HomeLogin,
        Login,
        Lock,
        Home,
        AddEditCipher,
        AutofillCiphers,
        SendAddEdit,
        OtpCipherSelection
    }
}
