﻿namespace Bit.Core.Enums
{
    public enum SecureNoteType : byte
    {
        Generic = 0
    }
}
