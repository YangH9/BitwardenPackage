﻿using System;
namespace Bit.Core.Enums
{
    public enum FileUploadType
    {
        Direct = 0,
        Azure = 1,
    }
}
