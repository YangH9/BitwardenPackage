﻿namespace Bit.Core.Enums
{
    public enum OrganizationUserStatusType : byte
    {
        Invited = 0,
        Accepted = 1,
        Confirmed = 2
    }
}
