﻿namespace Bit.Core.Enums
{
    public enum VerificationType
    {
        MasterPassword = 0,
        OTP = 1,
    }
}
