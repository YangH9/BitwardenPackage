type ScrollOptions = {
  delay: number;
  containerSelector: string;
};

export { ScrollOptions };
