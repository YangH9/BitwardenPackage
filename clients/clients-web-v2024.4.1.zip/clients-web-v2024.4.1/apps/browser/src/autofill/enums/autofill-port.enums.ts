const AutofillPort = {
  InjectedScript: "autofill-injected-script-port",
} as const;

export { AutofillPort };
